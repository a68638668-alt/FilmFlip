from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QHeaderView,
    QTableWidget,
)


class ImageTable(QTableWidget):
    """
    FilmFlip에서 사용하는 드래그 가능한 테이블
    """

    orderChanged = Signal()

    def __init__(self):
        super().__init__()

        self.setColumnCount(2)
        self.setHorizontalHeaderLabels(
            [
                "현재 파일명",
                "변경될 파일명",
            ]
        )

        self.horizontalHeader().setStretchLastSection(True)
        self.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch
        )

        self.setEditTriggers(
            QAbstractItemView.NoEditTriggers
        )

        self.setSelectionBehavior(
            QAbstractItemView.SelectRows
        )

        self.setSelectionMode(
            QAbstractItemView.SingleSelection
        )

        self.setDragEnabled(True)

        self.setAcceptDrops(True)

        self.viewport().setAcceptDrops(True)

        self.setDragDropOverwriteMode(False)

        self.setDropIndicatorShown(True)

        self.setDragDropMode(
            QAbstractItemView.InternalMove
        )

    def dropEvent(self, event):

        super().dropEvent(event)

        self.orderChanged.emit()